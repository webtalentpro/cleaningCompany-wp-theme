<?php

/**
 * Plugin Name:     Cleaning company Custom Post
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Handle the basics with this plugin.
 * Version: 1.0.0
 * Author:           Aminul Islam
 * Author URI:        https://author.example.com/

 
 */

// custom post 
function cleaningcompany_custom_post(){
    register_post_type( 'portfolio', array(
        'labels'=>array(
            'name'=> 'Our Projects',
            'singular_name'=>'Project',
            'add_new'=> 'Add New Project',
            'add_new_item'=> 'Add New Item',
            'view_item'=>'View Project',
            'edit_item'=> 'Edit Project',
            'not_found'=> 'No Project Found',

        ),
        'menu_icon'=> 'dashicons-images-alt',
        'description' => __( 'Add portfolio Item with describe', 'cleaningcompany' ),
        'public'=> true,
        'publicly_queryable'=> true,
        'show_ui'=> true,
        'has_archive'=> true,
        'hierarchical'=> true,
        'exclude_from_search'=> true,
        'capability_type'=>'post',
        'rewrite'=>array('slag'=> 'project'),
        'supports'=>array('title', 'thumbnail', 'editor'),
    ) );

}
add_action('init', 'cleaningcompany_custom_post' );